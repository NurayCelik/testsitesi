-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 23 Ara 2019, 10:56:24
-- Sunucu sürümü: 5.7.14
-- PHP Sürümü: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `dbase_cafe`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminId` int(11) NOT NULL,
  `adminName` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `adminUser` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `adminEmail` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `level` tinyint(4) NOT NULL,
  `adminPass` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminId`, `adminName`, `adminUser`, `adminEmail`, `level`, `adminPass`, `image`) VALUES
(1, 'Murat', 'admin', 'av.muratcelik@hotmail.com', 5, '$2y$11$fVn6lP9sxhr0nP64ZQrceOe83whKul2ubLRNJFZGcgdmFxLpTtXSC', '../../upload/admin/cd2fe60250.png');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_anasayfa`
--

CREATE TABLE `tbl_anasayfa` (
  `anasayfaId` int(11) NOT NULL,
  `markaBaslik1` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `markaBaslik2` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `markaImage` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `hakImage1` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `hakImage2` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `hakBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `hakIcerik` text COLLATE utf8_turkish_ci NOT NULL,
  `hakhref` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `kaliteImage` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `hizliImage` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `imageDogal` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `kaliteBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `kaliteIcerik` text COLLATE utf8_turkish_ci NOT NULL,
  `hizliBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `icerikHizli` text COLLATE utf8_turkish_ci NOT NULL,
  `dogalBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `icerikDogal` text COLLATE utf8_turkish_ci NOT NULL,
  `image1` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `image2` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `image3` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `image4` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `servisBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `servisIcerik1` text COLLATE utf8_turkish_ci NOT NULL,
  `servisHref1` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `servisIcerik2` text COLLATE utf8_turkish_ci NOT NULL,
  `servisHref2` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_anasayfa`
--

INSERT INTO `tbl_anasayfa` (`anasayfaId`, `markaBaslik1`, `markaBaslik2`, `markaImage`, `hakImage1`, `hakImage2`, `hakBaslik`, `hakIcerik`, `hakhref`, `kaliteImage`, `hizliImage`, `imageDogal`, `kaliteBaslik`, `kaliteIcerik`, `hizliBaslik`, `icerikHizli`, `dogalBaslik`, `icerikDogal`, `image1`, `image2`, `image3`, `image4`, `servisBaslik`, `servisIcerik1`, `servisHref1`, `servisIcerik2`, `servisHref2`) VALUES
(1, 'LEZZET CAFE', 'BeÄŸenilen Tatlar', '../../upload/anasayfa/b341a36d.jpg', '../../upload/anasayfa/a810560e.jpg', '../../upload/anasayfa/431555ca.jpg', 'DostluklarÄ±n Tarihi MekanÄ±', 'Lezzet Cafe Ã§eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetleri ile konuklarÄ±na geÃ§en zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyor.', 'HakkÄ±mÄ±zda', '../../upload/anasayfa/d40afcc7.jpg', '../../upload/anasayfa/ed9d8d5b.jpg', '../../upload/anasayfa/37b22d6e.jpg', 'Kaliteli Ãœretim', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'HÄ±zlÄ± Servis', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'DoÄŸal YÃ¶resel ÃœrÃ¼nler', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '../../upload/anasayfa/f19018ee.jpg', '../../upload/anasayfa/3604f33c.jpg', '../../upload/anasayfa/7efef202.jpg', '../../upload/anasayfa/a9cf9f1b.jpg', 'SERVÄ°SLERÄ°MÄ°Z', 'BÃ¶rek Ã§eÅŸitleri, cheesecake, sÃ¼tlÃ¼ tatlÄ±lar, yÃ¶resel lezzetler, dondurma ve iÃ§eceklerimizden oluÅŸan geniÅŸ bir yelpazede Ã¼rÃ¼n sunmaktan kÄ±vanÃ§ duyuyoruz.', 'ÃœrÃ¼nler', 'DÃ¼ÄŸÃ¼n resepsiyonlarÄ±, toplantÄ±lar, doÄŸum gÃ¼nÃ¼ partileri ve diÄŸer etkinlikleriniz iÃ§in de hizmet veriyoruz ve etkinliÄŸiniz iÃ§in Ã¶zel bir menÃ¼ oluÅŸturuyoruz.', 'Catering');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_apisocial`
--

CREATE TABLE `tbl_apisocial` (
  `socialapiId` int(11) NOT NULL,
  `recapctha` varchar(700) COLLATE utf8_turkish_ci NOT NULL,
  `mermapApi` varchar(700) COLLATE utf8_turkish_ci NOT NULL,
  `subemapApi` varchar(700) COLLATE utf8_turkish_ci NOT NULL,
  `goanalystic` varchar(700) COLLATE utf8_turkish_ci NOT NULL,
  `facebook` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `twitter` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `google` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `linkedin` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `instagram` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_apisocial`
--

INSERT INTO `tbl_apisocial` (`socialapiId`, `recapctha`, `mermapApi`, `subemapApi`, `goanalystic`, `facebook`, `twitter`, `google`, `linkedin`, `instagram`) VALUES
(1, 'no', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d46223.59051011185!2d36.17959970798343!3d36.203608814120805!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb29a3b5554024386!2sAvukat%20Murat%20%C3%87elik!5e0!3m2!1str!2str!4v1568888377852!5m2!1str!2str', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d46223.59051011185!2d36.17959970798343!3d36.203608814120805!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb29a3b5554024386!2sAvukat%20Murat%20%C3%87elik!5e0!3m2!1str!2str!4v1568888377852!5m2!1str!2str', 'no', 'http://www.facebook.com', 'http://www.twitter.com', 'http://www.google.com', 'http://www.linkedin.com', 'http://www.instagram.com');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_base`
--

CREATE TABLE `tbl_base` (
  `baseId` int(11) NOT NULL,
  `baseName` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `catId` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_base`
--

INSERT INTO `tbl_base` (`baseId`, `baseName`, `catId`) VALUES
(6, 'PoÄŸaÃ§a', 8),
(5, 'Simit', 8),
(7, 'AÃ§ma', 8),
(8, 'BÃ¶rek', 9),
(9, 'Pizza', 9),
(10, 'Burger', 9),
(26, 'Spagetti', 9),
(12, 'TrileÃ§e', 9),
(13, 'GÃ¼llaÃ§', 9),
(14, 'SÃ¼tlaÃ§', 9),
(15, 'Cheescake', 10),
(16, 'Tiramisu', 10),
(17, 'Pasta', 10),
(18, 'Tost', 11),
(19, 'Omlet', 11),
(20, 'KahvaltÄ± TabaÄŸÄ±', 11),
(21, 'Kahve', 15),
(22, 'Ã‡ay', 15),
(23, 'Milkshake', 15),
(25, 'Dondurma', 13);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_category`
--

CREATE TABLE `tbl_category` (
  `catId` int(11) NOT NULL,
  `catName` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_category`
--

INSERT INTO `tbl_category` (`catId`, `catName`) VALUES
(11, 'KahvaltÄ±lar'),
(9, 'Spesiyaller'),
(8, 'Cafeden'),
(10, 'TatlÄ±lar'),
(15, 'Ä°Ã§ecekler'),
(13, 'Dondurmalar');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_catering`
--

CREATE TABLE `tbl_catering` (
  `cateringId` int(11) NOT NULL,
  `baslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `altBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `icerik` text COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_catering`
--

INSERT INTO `tbl_catering` (`cateringId`, `baslik`, `altBaslik`, `icerik`) VALUES
(1, 'Catering', 'Bir Tabak Ä°ster Misiniz?', 'DÃ¼ÄŸÃ¼n resepsiyonlarÄ±, prova yemekleri, ofis partileri, toplantÄ±lar, doÄŸum gÃ¼nÃ¼ partileri ve diÄŸer etkinlikleriniz iÃ§in Lezzet Cafe saha dÄ±ÅŸÄ±nda da hizmet verir ve etkinliÄŸiniz iÃ§in Ã¶zel bir menÃ¼ oluÅŸturur. Tesis bÃ¼nyesinde de iÃ§ecek ve yemek servisi mevcuttur. Hizmetlerimiz arasÄ±nda Kokteyl Organizasyon / Coffee Break / KahvaltÄ± - Brunch / AÃ§Ä±k BÃ¼fe Yemek - Buffet / BarbekÃ¼ - BBQ bulunmaktadÄ±r. Bir istek gÃ¶ndermek veya daha fazla bilgi almak iÃ§in buradan bize ulaÅŸabilirsiniz.');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_form`
--

CREATE TABLE `tbl_form` (
  `formId` int(11) NOT NULL,
  `ad` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `soyad` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `telefon` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `mesaj` text COLLATE utf8_turkish_ci NOT NULL,
  `tarih` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_galericatering`
--

CREATE TABLE `tbl_galericatering` (
  `galeriCateringId` int(11) NOT NULL,
  `sira` int(3) NOT NULL,
  `image` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_galericatering`
--

INSERT INTO `tbl_galericatering` (`galeriCateringId`, `sira`, `image`) VALUES
(21, 1, 'upload/galericatering/52346153df.jpg'),
(22, 2, '../../upload/galericatering/371472dd05.jpg'),
(23, 3, '../../upload/galericatering/ee9548eea5.jpg'),
(24, 4, '../../upload/galericatering/afa8a39417.jpg'),
(25, 5, '../../upload/galericatering/543eb36dca.jpg'),
(26, 6, '../../upload/galericatering/2658583d62.jpg'),
(27, 7, '../../upload/galericatering/012c25f343.jpg'),
(28, 8, '../../upload/galericatering/9ae579ca6d.jpg'),
(29, 9, '../../upload/galericatering/9ff9e1923c.jpg'),
(30, 10, '../../upload/galericatering/b735b0d226.jpg'),
(31, 11, '../../upload/galericatering/5b53d252dc.jpg'),
(32, 12, '../../upload/galericatering/1d16c1d1b7.jpg'),
(33, 13, '../../upload/galericatering/386065c2ad.jpg'),
(34, 14, '../../upload/galericatering/f1ffd32aee.jpg'),
(35, 15, '../../upload/galericatering/db2929bad3.jpg'),
(36, 16, '../../upload/galericatering/9d1b840172.jpg'),
(37, 17, '../../upload/galericatering/5292622582.jpg'),
(38, 18, '../../upload/galericatering/aea384d7b9.jpg'),
(39, 19, '../../upload/galericatering/22bbcf1e2b.jpg'),
(40, 20, '../../upload/galericatering/d0d2f46fb5.jpg'),
(41, 21, '../../upload/galericatering/ece72a75dd.jpg'),
(42, 22, '../../upload/galericatering/d37cac4411.jpg'),
(43, 23, '../../upload/galericatering/7d9b4edc37.jpg'),
(44, 24, '../../upload/galericatering/4c65d8e808.jpg'),
(45, 25, '../../upload/galericatering/2c9e368251.jpg'),
(46, 26, '../../upload/galericatering/885696b404.jpg'),
(47, 27, '../../upload/galericatering/cf9822efe5.jpg'),
(48, 28, '../../upload/galericatering/66fb2b3969.jpg'),
(49, 29, '../../upload/galericatering/d2cd74f0c3.jpg'),
(50, 30, '../../upload/galericatering/2cb1f138d5.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_haber`
--

CREATE TABLE `tbl_haber` (
  `haberId` int(11) NOT NULL,
  `haberBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `haberDetay` text COLLATE utf8_turkish_ci NOT NULL,
  `haberKaynak` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `haberSira` int(2) NOT NULL,
  `haberDurum` tinyint(4) NOT NULL DEFAULT '1',
  `haberTarih` date NOT NULL,
  `image` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_haber`
--

INSERT INTO `tbl_haber` (`haberId`, `haberBaslik`, `haberDetay`, `haberKaynak`, `haberSira`, `haberDurum`, `haberTarih`, `image`) VALUES
(1, 'Lezzet Cafe\'den yeni Ã¼rÃ¼nler', 'Teknolojik ilerleme ve geliÅŸmeyle insanlÄ±k, kÃ¼ltÃ¼r ve medeniyet hayatÄ± beraber mi geliÅŸip ilerler yoksa bunlar birbirinden baÄŸÄ±msÄ±z ÅŸeyler midir? Ä°nsanlar ÅŸimdi mi daha medeni yoksa eski insanlar mÄ± daha medeniydi? Ä°nsan ve insanlÄ±k Ã¼zerine olan bu soruda tanÄ±klÄ±ÄŸÄ± insana yaptÄ±rmak doÄŸru olmaz elbette. TanÄ±k kÃ¼rsÃ¼sÃ¼ne kuÅŸlarÄ± Ã§aÄŸÄ±rsak ve sorsak; Siz hangi dÃ¶nemin insanlarÄ±nda gÃ¶rdÃ¼nÃ¼z sevgiyi, ÅŸefkati ve zerafeti? CevaplarÄ± ne olurdu acaba? Bu Ã§aÄŸda bu gÃ¼nlerde gÃ¶rdÃ¼k, sizler teknolojik olarak ilerledikÃ§e geliÅŸtikÃ§e, ÅŸehirleriniz bÃ¼yÃ¼dÃ¼kÃ§e bizle daha fazla ilgilenir, daha fazla dÃ¼ÅŸÃ¼nÃ¼r, dÃ¼nyanÄ±zda bize daha fazla yer verir oldunuz, bize karÅŸÄ± sevgi ÅŸefkat ve zerafetiniz arttÄ± mÄ± derler yoksa bize geÃ§miÅŸte ve geride kalan baÅŸka dÃ¶nemlerden mi bahsederler?\r\nDÃ¼nyanÄ±n neresinde hangi coÄŸrafyada hangi Ã¼lkede size sevgi ve ÅŸefkat gÃ¶sterdi insan denilse acaba ne cevap verirler? Tarihi gerÃ§ekler Ä±ÅŸÄ±ÄŸÄ±nda kuÅŸlarÄ±n cevaplarÄ±na geÃ§elim. â€œâ€¦Anadoluâ€™nun pek Ã§ok ÅŸehrinde 1400â€™lÃ¼ yÄ±llardan 1900â€™lÃ¼ yÄ±llara kadar 600 yÄ±l boyunca TÃ¼rkler biz kuÅŸlar iÃ§in evler, kÃ¶ÅŸkler ve saraylar yaptÄ±lar. SÄ±radan yuvalar, sÄ±radan yapÄ±lar deÄŸildi bunlar. Ä°nsanÄ±n kendi iÃ§in yaptÄ±ÄŸÄ± kÃ¶ÅŸkler saraylar gibi harika mimari eserlerdi. Bu eserleri bizim iÃ§in yabanda yapmadÄ±lar. Åžehirlerin iÃ§inde, kendi evlerinde, camilerinde, hanlarda, hamamlarda, kÃ¶prÃ¼lerde, medreselerde yani iÃ§ iÃ§e olduÄŸumuz yerlerde yaptÄ±lar. HayatÄ± bizimle paylaÅŸtÄ±klarÄ±nÄ±n, dÃ¼nyanÄ±n sadece insan iÃ§in var olmadÄ±ÄŸÄ±nÄ±n muhteÅŸem bir biÃ§imde farkÄ±ndaydÄ±lar. Ã–yle ki biz kuÅŸlar ve diÄŸer hayvanlar iÃ§in vakÄ±flar kurdular. Bu vakÄ±flarÄ±n tahsisatlarÄ± ile yÃ¼zyÄ±llarca kuÅŸlar ve hayvanlar beslendiler, barÄ±ndÄ±lar ve veteriner hizmetleri aldÄ±lar. Yani biz kuÅŸlar ÅŸahitlik ederiz ki, biz en baÅŸta Anadolu coÄŸrafyasÄ±nda, SelÃ§ukluâ€™da, sonra OsmanlÄ±â€™yla ilaveten Balkan coÄŸrafyasÄ±nda sevgi ÅŸefkat gÃ¶rdÃ¼k zarif insanlar tanÄ±dÄ±k. EcdadÄ±nÄ±z doÄŸaya, hayvanata sizlerden daha duyarlÄ±ydÄ±, daha sevgi ve ÅŸefkat dolulardÄ±, bizlere Ã¼stelik dÃ¼nyanÄ±n hiÃ§bir yerinde ve hiÃ§bir zaman olmadÄ±ÄŸÄ± kadar.', 'Yeni Express Gazetesi', 1, 1, '2019-07-20', '../../upload/haberFoto/080ebe2339.jpg'),
(2, 'ÃœnlÃ¼ler Lezzet Cafe\'de', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.&amp;quot;&amp;quot;&amp;nbsp; &amp;nbsp; agfsadsa2222&amp;quot;&amp;quot;&amp;quot;', 'Yeni Express Gazetesi', 2, 1, '2019-05-25', '../../upload/haberFoto/a1531944ec.jpg'),
(3, 'Lezzet Cafe 2. ÅžubesiÌ‡niÌ‡ AÃ§ti', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Yeni Express Gazetesi', 3, 1, '2015-11-20', '../../upload/haberFoto/3a8adeb8de.png'),
(4, 'Lezzet Cafe\'ye Kalite Belgesi', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Yeni Express Gazetesi', 4, 1, '2019-04-30', '../../upload/haberFoto/532ec6a566.jpg'),
(5, 'Gazeteciler Lezzet Cafe\'de buluÅŸtu', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.&amp;quot;', 'Yeni Express Gazetesi', 5, 1, '2019-12-28', '../../upload/haberFoto/c2ed619600.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_hakkimizda`
--

CREATE TABLE `tbl_hakkimizda` (
  `hakkimizdaId` int(11) NOT NULL,
  `ustBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `baslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `icerik1` text COLLATE utf8_turkish_ci NOT NULL,
  `icerik2` text COLLATE utf8_turkish_ci NOT NULL,
  `icerik3` text COLLATE utf8_turkish_ci NOT NULL,
  `image1` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `image2` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `ortaBaslik1` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `ortaBaslik2` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `imageOrta` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `altBaslik1` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `altIcerik1` text COLLATE utf8_turkish_ci NOT NULL,
  `altBaslik2` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `altIcerik2` text COLLATE utf8_turkish_ci NOT NULL,
  `altBaslik3` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `altIcerik3` text COLLATE utf8_turkish_ci NOT NULL,
  `altImage1` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `altImage2` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `altImage3` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_hakkimizda`
--

INSERT INTO `tbl_hakkimizda` (`hakkimizdaId`, `ustBaslik`, `baslik`, `icerik1`, `icerik2`, `icerik3`, `image1`, `image2`, `ortaBaslik1`, `ortaBaslik2`, `imageOrta`, `altBaslik1`, `altIcerik1`, `altBaslik2`, `altIcerik2`, `altBaslik3`, `altIcerik3`, `altImage1`, `altImage2`, `altImage3`) VALUES
(1, 'Biz', 'LEZZET CAFE AÄ°LESÄ°YÄ°Z', 'Lezzet Cafe Ã§eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetlerimiz ile zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyoruz.', 'Unlu mamÃ¼llerimizin yanÄ±sÄ±ra Ã¶zel tatlÄ±larÄ±mÄ±z ve yine enfes iÃ§eceklerimiz ile sÄ±cak ve nezih mekanÄ±mÄ±zda konuklarÄ±mÄ±zÄ± aÄŸÄ±rlamaktan bÃ¼yÃ¼k bir gurur duyuyoruz.', 'KuÅŸkusuz bÃ¼yÃ¼k beÄŸeni toplamÄ±mÄ±zÄ±n arkasÄ±nda uzman ellerde Ã¶zverilerle titiz ve hijyen kurallarÄ±na uygun olarak Ã§alÄ±ÅŸmamÄ±zÄ±n payÄ± Ã§ok bÃ¼yÃ¼ktÃ¼r', '../../upload/hakkimizda/26978277.png', '../../upload/hakkimizda/f3ca3907.jpg', 'MÃ¼kemmel', 'SonuÃ§', '../../upload/hakkimizda/fc6b2a32.jpg', 'Misyonumuz', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Vizyonumuz', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Kariyer', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '../../upload/hakkimizda/6d69e1e4.jpg', '../../upload/hakkimizda/04e953af.jpg', '../../upload/hakkimizda/d6881966.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_iletisim`
--

CREATE TABLE `tbl_iletisim` (
  `iletisimId` int(11) NOT NULL,
  `merkezTel` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `subeTel` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `gsmNo` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `mailAdres` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `merkezAdres` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `milce` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `mil` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `mimage` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `subeAdres` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `subeilce` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `subeil` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `simage` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `mesaiSaat` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_iletisim`
--

INSERT INTO `tbl_iletisim` (`iletisimId`, `merkezTel`, `subeTel`, `gsmNo`, `mailAdres`, `merkezAdres`, `milce`, `mil`, `mimage`, `subeAdres`, `subeilce`, `subeil`, `simage`, `mesaiSaat`) VALUES
(1, '0 212 0000000', '0 212 0100000', '0 535 0000000', 'info@lezzetcafe.xyz', 'Ãœrgen PaÅŸa Mah. No: 00', 'Antakya', 'Hatay', '../../upload/site/ffe6231c.jpg', 'Ãœrgen PaÅŸa Mah. No:00', 'Ä°skenderun', 'Hatay', '../../upload/site/f66a636f.jpg', 'Pazarâ€“ Cumartesi: 6:00 - 12:00');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_instagaleri`
--

CREATE TABLE `tbl_instagaleri` (
  `instagramId` int(11) NOT NULL,
  `sira` int(2) NOT NULL,
  `image` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_instagaleri`
--

INSERT INTO `tbl_instagaleri` (`instagramId`, `sira`, `image`) VALUES
(1, 1, '../../upload/instagramgaleri/36c02b98f6.jpg'),
(2, 2, '../../upload/instagramgaleri/cc4538367f.jpg'),
(3, 3, '../../upload/instagramgaleri/aa281d1c7e.jpg'),
(4, 4, '../../upload/instagramgaleri/1882facc6d.jpg'),
(5, 5, '../../upload/instagramgaleri/ea4b4587c8.jpg'),
(6, 6, 'upload/instagramgaleri/a9215f46e4.jpg'),
(7, 7, '../../upload/instagramgaleri/d52442cab4.jpg'),
(8, 8, '../../upload/instagramgaleri/9320fb7e3a.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_medya`
--

CREATE TABLE `tbl_medya` (
  `medyaId` int(11) NOT NULL,
  `medyaBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `baslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `ortaBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `ortaAltBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `altBaslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `takipci` varchar(255) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_medya`
--

INSERT INTO `tbl_medya` (`medyaId`, `medyaBaslik`, `baslik`, `ortaBaslik`, `ortaAltBaslik`, `image`, `altBaslik`, `takipci`) VALUES
(1, 'Medya', 'Etkinliklerimizden Kareler', 'Naturel', 'Tatlar', '../../upload/medya/73021465.jpg', 'Instagram\\\'da Lezzet Cafe', '500,000 TakipÃ§i');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_menu`
--

CREATE TABLE `tbl_menu` (
  `menuId` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `menuName` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `menuDetay` text COLLATE utf8_turkish_ci NOT NULL,
  `menuUrl` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `menuSira` int(2) NOT NULL,
  `menuDurum` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_menu`
--

INSERT INTO `tbl_menu` (`menuId`, `image`, `menuName`, `menuDetay`, `menuUrl`, `menuSira`, `menuDurum`) VALUES
(1, '../../upload/menu/0936e5a74a.jpg', 'Anasayfa', 'nxbvx&amp;quot;&amp;quot;&amp;quot;&amp;quot;&amp;quot;', 'index.php', 1, 1),
(2, '../../upload/menu/38c8c4f5fd.jpg', 'HakkÄ±mÄ±zda', 'fb&amp;quot;', 'hakkimizda.php', 2, 1),
(3, '../../upload/menu/672d732f37.jpg', 'ÃœrÃ¼nler', 'c cv&amp;quot;', 'urunler.php', 3, 1),
(4, '../../upload/menu/a964e816fe.jpg', 'CaterÄ±ng', 'zxcx&amp;quot;&amp;quot;', 'catering.php', 4, 1),
(5, '../../upload/menu/cb488c419b.jpg', 'Medya', 'dSD&amp;quot;', 'medya.php', 5, 1),
(6, '../../upload/menu/c48420d648.jpg', 'Ä°letiÅŸim', 'sfdAS&amp;quot;', 'iletisim.php', 6, 1),
(7, '../../upload/menu/b27cc4d0a3.jpg', 'ÃœrÃ¼n', 'cb x&amp;quot;&amp;quot;&amp;quot;', 'urun.php', 7, 1),
(10, '../../upload/menu/d4c3e429d8.jpg', 'Search', 'Search&amp;quot;&amp;quot;&amp;quot;&amp;quot;', 'search.php', 8, 0),
(11, '../../upload/menu/dbb9d554a0.jpg', 'Kategori', 'aaa&amp;quot;&amp;quot;', 'kategori.php', 9, 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_product`
--

CREATE TABLE `tbl_product` (
  `productId` int(11) NOT NULL,
  `productName` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `baseId` int(11) NOT NULL,
  `catId` int(11) NOT NULL,
  `body` text COLLATE utf8_turkish_ci NOT NULL,
  `price` float NOT NULL,
  `image` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `imageYedek` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_product`
--

INSERT INTO `tbl_product` (`productId`, `productName`, `baseId`, `catId`, `body`, `price`, `image`, `imageYedek`, `type`) VALUES
(15, 'Zeytinli AÃ§ma', 7, 8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 4, '../../upload/urunler/1b52b306.jpg', '../../upload/urunler/6211db2d.jpg', 0),
(13, 'Zeytinli PoÄŸaÃ§a', 6, 8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 4, '../../upload/urunler/9592733db5.jpg', '', 1),
(14, 'Sade AÃ§ma', 7, 8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 4, '../../upload/urunler/6287b7ca68.jpg', '../../upload/urunler/6f3169a4.jpg', 1),
(12, 'Peynirli PoÄŸaÃ§a', 6, 8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 4, '../../upload/urunler/44c28b66dd.jpg', '', 1),
(10, 'KaÅŸarlÄ± PoÄŸaÃ§a ', 6, 8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 4, '../../upload/urunler/ff21627818.jpg', '', 1),
(11, 'Sade PoÄŸaÃ§a', 6, 8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 3, '../../upload/urunler/c7a1269904.jpg', '', 1),
(8, 'Simit', 5, 8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 3, '../../upload/urunler/d0dc926673.jpg', '', 1),
(9, 'KaÅŸarlÄ± Simit', 5, 8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 5, '../../upload/urunler/9b0081399d.jpg', '', 1),
(16, 'Su BÃ¶reÄŸi', 8, 9, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/cd3cc6d434.jpg', '', 1),
(17, 'KÄ±ymalÄ± Su BÃ¶reÄŸi ', 8, 9, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/220581f20b.jpg', '', 1),
(18, 'Pizza', 9, 9, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 20, '../../upload/urunler/84e40f2738.jpg', '', 1),
(19, 'KaÅŸarlÄ± Burger', 10, 9, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 20, '../../upload/urunler/fcfc6b2773.jpg', '', 0),
(20, 'Cheeseburger ', 10, 9, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 25, '../../upload/urunler/7515a6d6ff.jpg', '', 0),
(21, 'TrileÃ§e ', 12, 9, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/7fe5acce3f.png', '', 0),
(22, 'SÃ¼tlaÃ§', 14, 9, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/118bb7ea4c.png', '', 0),
(23, 'MantarlÄ± Spagetti', 26, 9, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/c557897d29.jpg', '', 1),
(24, 'FrambuazlÄ± Cheescake', 15, 10, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 20, '../../upload/urunler/2eaaa6fe1f.jpg', '../../upload/urunler/524c8e7b.png', 0),
(25, 'Ã‡ikolatalÄ± Cheescake', 15, 10, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 20, '../../upload/urunler/7b2962abab.jpg', '', 0),
(26, 'Limonlu Cheescake', 15, 10, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 20, '../../upload/urunler/7f09eb32d7.jpg', '', 0),
(27, 'Tiramisu', 16, 10, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 20, '../../upload/urunler/1639519a1a.jpg', '', 0),
(28, 'YaÅŸ Pasta', 17, 10, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 20, '../../upload/urunler/8ca969689b.jpg', '', 0),
(29, 'Muzlu YaÅŸ Pasta', 17, 10, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 20, '../../upload/urunler/9a3d634b2c.jpg', '', 0),
(30, 'KarÄ±ÅŸÄ±k KahvaltÄ±', 20, 11, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 20, '../../upload/urunler/77abb75e12.jpg', '', 0),
(31, 'KÃ¶y KahvaltÄ±sÄ±', 20, 11, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 30, '../../upload/urunler/40cf48c7c9.jpg', '', 0),
(32, 'KaÅŸarlÄ± Tost', 18, 11, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/237b65391b.jpg', '', 0),
(33, 'KarÄ±ÅŸÄ±k Tost', 18, 11, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/8e23a2015c.jpg', '', 1),
(34, 'Espresso', 21, 15, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 10, '../../upload/urunler/4379053790.jpg', '', 0),
(35, 'TÃ¼rk Kahvesi', 21, 15, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 10, '../../upload/urunler/fdda3c1678.jpg', '', 0),
(36, 'Cappucino', 21, 15, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 10, '../../upload/urunler/8fead27f21.jpg', '', 0),
(37, 'Filtre Kahve', 21, 15, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 10, '../../upload/urunler/162779df5a.jpg', '', 0),
(38, 'Ã‡ay', 22, 15, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 10, '../../upload/urunler/db72db6531.jpg', '', 0),
(39, 'Ihlamur', 22, 15, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 10, '../../upload/urunler/bccdb6735a.jpg', '', 0),
(40, 'AdaÃ§ayÄ±', 22, 15, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 10, '../../upload/urunler/6569cd4777.jpg', '../../upload/urunler/91fa109f.jpg', 0),
(41, 'Ã‡ilekli Milkshake', 23, 15, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/146fa284a7.jpg', '../../upload/urunler/2ea98385.jpg', 0),
(42, 'Ã‡ilekli Dondurma', 25, 13, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 20, '../../upload/urunler/496c2fee0f.jpg', '../../upload/urunler/0dab5e5c.jpg', 0),
(43, 'Sade Dondurma', 25, 13, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/a7158b99c3.jpg', '../../upload/urunler/6ab8c68a.jpg', 0),
(44, 'Kakaolu Dondurma', 25, 13, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/bcb2421ff9.jpg', '../../upload/urunler/19889aa4.jpg', 0),
(45, 'VanilyalÄ± Dondurma', 25, 13, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/ea0eff225c.jpg', '', 0),
(46, 'Limonlu Dondurma', 25, 13, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 15, '../../upload/urunler/2398ad43ff.jpg', '../../upload/urunler/d3d516cf.jpg', 0),
(47, 'FÄ±stÄ±klÄ± YaÅŸ Pasta', 17, 10, 'Lorem Ipsum, dizgi ve baskÄ± end&amp;uuml;strisinde kullanÄ±lan mÄ±gÄ±r metinlerdir. Lorem Ipsum, adÄ± bilinmeyen bir matbaacÄ±nÄ±n bir hurufat numune kitabÄ± oluÅŸturmak &amp;uuml;zere bir yazÄ± galerisini alarak karÄ±ÅŸtÄ±rdÄ±ÄŸÄ± 1500&amp;#39;lerden beri end&amp;uuml;stri standardÄ± sahte metinler olarak kullanÄ±lmÄ±ÅŸtÄ±r. BeÅŸy&amp;uuml;z yÄ±l boyunca varlÄ±ÄŸÄ±nÄ± ', 40, '../../upload/urunler/c13bb433.jpg', '../../upload/urunler/47119d97.jpg', 1),
(48, 'Meyveli YaÅŸ Pasta', 17, 10, 'Lezzet Cafe &amp;ccedil;eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetlerimiz ile zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyoruz.\r\n\r\n', 20, '../../upload/urunler/18bcd8ce.jpg', '../../upload/urunler/123e288f.jpg', 1),
(49, 'Karamelli Dondurma', 25, 13, 'Lezzet Cafe &amp;ccedil;eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetlerimiz ile zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyoruz.\r\n\r\nLezzet Cafe &amp;ccedil;eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetlerimiz ile zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyoruz.\r\n\r\nLezzet Cafe &amp;ccedil;eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetlerimiz ile zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyoruz.', 10, '../../upload/urunler/13b33fba.jpg', '../../upload/urunler/54f25b5b.jpg', 1),
(50, 'Kivili Dondurma', 25, 13, 'Lezzet Cafe &amp;ccedil;eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetlerimiz ile zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyoruz.\r\n\r\nLezzet Cafe &amp;ccedil;eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetlerimiz ile zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyoruz.\r\n\r\nLezzet Cafe &amp;ccedil;eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetlerimiz ile zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyoruz.', 10, '../../upload/urunler/6ffef490.jpg', '../../upload/urunler/95a3b1e8.jpg', 1),
(51, 'FrambuazlÄ± Dondurma', 25, 13, 'Lezzet Cafe Ã§eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetlerimiz ile zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyoruz.\r\n\r\nLezzet Cafe Ã§eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetlerimiz ile zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyoruz.\r\n\r\nLezzet Cafe Ã§eyrek asÄ±rdÄ±r siz deÄŸerli dostlarÄ±n buluÅŸma noktasÄ± oldu. EÅŸsiz lezzetlerimiz ile zamanda unutulmaz hatÄ±ralar bÄ±rakmaya devam ediyoruz.', 10.05, '../../upload/urunler/a8ca7398.jpg', '../../upload/urunler/be6f936f.jpg', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_site`
--

CREATE TABLE `tbl_site` (
  `siteId` int(11) NOT NULL,
  `LogoMd` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `LogoLg` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `siteUrl` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `siteName` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `siteDescr` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `siteKeys` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `siteauthor` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `copyright` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `tarih` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_site`
--

INSERT INTO `tbl_site` (`siteId`, `LogoMd`, `LogoLg`, `siteUrl`, `siteName`, `siteDescr`, `siteKeys`, `siteauthor`, `copyright`, `tarih`) VALUES
(1, '../../upload/site/66e8e705.jpg', '../../upload/site/a320f475.jpg', 'http://www.lezzetcafe.xyz', 'Lezzet Cafe', 'Lezzet Cafe YazÄ±lÄ±m Projesi', 'Cafe, Catering, Lezzet, Kek, BÃ¶rek', 'Nuray Ã‡elik', 'Anka YazÄ±lÄ±m', '2019-10-20');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `sliderId` int(11) NOT NULL,
  `sliderName` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `sliderLink` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `sliderSira` int(2) NOT NULL,
  `sliderDurum` tinyint(4) DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_slider`
--

INSERT INTO `tbl_slider` (`sliderId`, `sliderName`, `image`, `sliderLink`, `sliderSira`, `sliderDurum`) VALUES
(4, 'Marka', '../../upload/slider/d568c90fb1.jpg', 'http:', 1, 1),
(5, 'Marka1', '../../upload/slider/5508549e22.jpg', 'http://', 2, 1),
(6, 'Marka2', '../../upload/slider/2eca4559c5.jpg', 'http://', 3, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tbl_video`
--

CREATE TABLE `tbl_video` (
  `videoId` int(11) NOT NULL,
  `videoName` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `video` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `videoLink` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `videoSira` int(2) NOT NULL,
  `videoDurum` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `tbl_video`
--

INSERT INTO `tbl_video` (`videoId`, `videoName`, `video`, `videoLink`, `videoSira`, `videoDurum`) VALUES
(11, 'Lezzet Cafe KahvaltÄ±', '../../upload/video/f328f3be9f.mp4', 'http://', 1, 1),
(12, 'Lezzet Cafe TanÄ±tÄ±m 1', '../../upload/video/0a54ae9b7a.mp4', 'http://', 2, 1),
(13, 'Lezzet Cafe TanÄ±tÄ±m5', '../../upload/video/eebf6af6c1.mp4', 'http://', 3, 1);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Tablo için indeksler `tbl_anasayfa`
--
ALTER TABLE `tbl_anasayfa`
  ADD PRIMARY KEY (`anasayfaId`);

--
-- Tablo için indeksler `tbl_apisocial`
--
ALTER TABLE `tbl_apisocial`
  ADD PRIMARY KEY (`socialapiId`);

--
-- Tablo için indeksler `tbl_base`
--
ALTER TABLE `tbl_base`
  ADD PRIMARY KEY (`baseId`);

--
-- Tablo için indeksler `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`catId`);

--
-- Tablo için indeksler `tbl_catering`
--
ALTER TABLE `tbl_catering`
  ADD PRIMARY KEY (`cateringId`);

--
-- Tablo için indeksler `tbl_form`
--
ALTER TABLE `tbl_form`
  ADD PRIMARY KEY (`formId`);

--
-- Tablo için indeksler `tbl_galericatering`
--
ALTER TABLE `tbl_galericatering`
  ADD PRIMARY KEY (`galeriCateringId`),
  ADD UNIQUE KEY `sira` (`sira`);

--
-- Tablo için indeksler `tbl_haber`
--
ALTER TABLE `tbl_haber`
  ADD PRIMARY KEY (`haberId`),
  ADD UNIQUE KEY `haberSira` (`haberSira`);

--
-- Tablo için indeksler `tbl_hakkimizda`
--
ALTER TABLE `tbl_hakkimizda`
  ADD PRIMARY KEY (`hakkimizdaId`);

--
-- Tablo için indeksler `tbl_iletisim`
--
ALTER TABLE `tbl_iletisim`
  ADD PRIMARY KEY (`iletisimId`);

--
-- Tablo için indeksler `tbl_instagaleri`
--
ALTER TABLE `tbl_instagaleri`
  ADD PRIMARY KEY (`instagramId`),
  ADD UNIQUE KEY `sira` (`sira`);

--
-- Tablo için indeksler `tbl_medya`
--
ALTER TABLE `tbl_medya`
  ADD PRIMARY KEY (`medyaId`);

--
-- Tablo için indeksler `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`menuId`),
  ADD UNIQUE KEY `constraint2` (`menuSira`);

--
-- Tablo için indeksler `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`productId`);

--
-- Tablo için indeksler `tbl_site`
--
ALTER TABLE `tbl_site`
  ADD PRIMARY KEY (`siteId`);

--
-- Tablo için indeksler `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`sliderId`),
  ADD UNIQUE KEY `constraintNo` (`sliderSira`);

--
-- Tablo için indeksler `tbl_video`
--
ALTER TABLE `tbl_video`
  ADD PRIMARY KEY (`videoId`),
  ADD UNIQUE KEY `constraintSira` (`videoSira`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_anasayfa`
--
ALTER TABLE `tbl_anasayfa`
  MODIFY `anasayfaId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_apisocial`
--
ALTER TABLE `tbl_apisocial`
  MODIFY `socialapiId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_base`
--
ALTER TABLE `tbl_base`
  MODIFY `baseId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_catering`
--
ALTER TABLE `tbl_catering`
  MODIFY `cateringId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_form`
--
ALTER TABLE `tbl_form`
  MODIFY `formId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=378;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_galericatering`
--
ALTER TABLE `tbl_galericatering`
  MODIFY `galeriCateringId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_haber`
--
ALTER TABLE `tbl_haber`
  MODIFY `haberId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_hakkimizda`
--
ALTER TABLE `tbl_hakkimizda`
  MODIFY `hakkimizdaId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_iletisim`
--
ALTER TABLE `tbl_iletisim`
  MODIFY `iletisimId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_instagaleri`
--
ALTER TABLE `tbl_instagaleri`
  MODIFY `instagramId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_medya`
--
ALTER TABLE `tbl_medya`
  MODIFY `medyaId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_menu`
--
ALTER TABLE `tbl_menu`
  MODIFY `menuId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_site`
--
ALTER TABLE `tbl_site`
  MODIFY `siteId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `sliderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- Tablo için AUTO_INCREMENT değeri `tbl_video`
--
ALTER TABLE `tbl_video`
  MODIFY `videoId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
